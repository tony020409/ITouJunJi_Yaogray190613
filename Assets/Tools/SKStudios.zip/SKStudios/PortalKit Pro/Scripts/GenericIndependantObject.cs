﻿using SKStudios.Portals;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenericIndependantObject : TeleportableScript {

    // Update is called once per frame
    public override void CustomUpdate() {
        base.CustomUpdate();
    }
}
